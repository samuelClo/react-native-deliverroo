export default {
    primary: '#6aeac3',
    secondary: '#ed4a62',
    backgroundGray: '#fefefe',
    lightGray: '#f9fbfa',
    lightGrayDarken: '#f5f6f6',
    FONT: {
        gray: '#cccecd',
        darkGray: '#474d4c',
    }
}